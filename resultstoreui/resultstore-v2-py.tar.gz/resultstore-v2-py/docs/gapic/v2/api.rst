Client for Result Store API
===========================

.. automodule:: google.devtools.resultstore_v2
    :members:
    :inherited-members: