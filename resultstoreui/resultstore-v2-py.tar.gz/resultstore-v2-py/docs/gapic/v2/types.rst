Types for Result Store API Client
=================================

.. automodule:: google.devtools.resultstore_v2.types
    :members: