# -*- coding: utf-8 -*-
#
# Copyright 2020 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Unit tests."""

import mock
import pytest

from google.devtools import resultstore_v2
from google.devtools.resultstore_v2.proto import action_pb2
from google.devtools.resultstore_v2.proto import configuration_pb2
from google.devtools.resultstore_v2.proto import configured_target_pb2
from google.devtools.resultstore_v2.proto import file_set_pb2
from google.devtools.resultstore_v2.proto import invocation_pb2
from google.devtools.resultstore_v2.proto import resultstore_upload_pb2
from google.devtools.resultstore_v2.proto import target_pb2
from google.devtools.resultstore_v2.proto import upload_metadata_pb2
from google.protobuf import empty_pb2



class MultiCallableStub(object):
    """Stub for the grpc.UnaryUnaryMultiCallable interface."""
    def __init__(self, method, channel_stub):
        self.method = method
        self.channel_stub = channel_stub

    def __call__(self, request, timeout=None, metadata=None, credentials=None):
        self.channel_stub.requests.append((self.method, request))

        response = None
        if self.channel_stub.responses:
            response = self.channel_stub.responses.pop()

        if isinstance(response, Exception):
            raise response

        if response:
            return response


class ChannelStub(object):
    """Stub for the grpc.Channel interface."""
    def __init__(self, responses = []):
        self.responses = responses
        self.requests = []

    def unary_unary(
            self, method, request_serializer=None, response_deserializer=None):
        return MultiCallableStub(method, self)


class CustomException(Exception):
    pass


class TestResultStoreUploadClient(object):

    def test_create_invocation(self):
        # Setup Expected Response
        name = 'name3373707'
        expected_response = {'name': name}
        expected_response = invocation_pb2.Invocation(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        response = client.create_invocation()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_upload_pb2.CreateInvocationRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_create_invocation_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        with pytest.raises(CustomException):
            client.create_invocation()

    def test_update_invocation(self):
        # Setup Expected Response
        name = 'name3373707'
        expected_response = {'name': name}
        expected_response = invocation_pb2.Invocation(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        response = client.update_invocation()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_upload_pb2.UpdateInvocationRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_update_invocation_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        with pytest.raises(CustomException):
            client.update_invocation()

    def test_merge_invocation(self):
        # Setup Expected Response
        name = 'name3373707'
        expected_response = {'name': name}
        expected_response = invocation_pb2.Invocation(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        response = client.merge_invocation()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_upload_pb2.MergeInvocationRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_merge_invocation_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        with pytest.raises(CustomException):
            client.merge_invocation()

    def test_touch_invocation(self):
        # Setup Expected Response
        name = 'name3373707'
        expected_response = {'name': name}
        expected_response = resultstore_upload_pb2.TouchInvocationResponse(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        response = client.touch_invocation()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_upload_pb2.TouchInvocationRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_touch_invocation_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        with pytest.raises(CustomException):
            client.touch_invocation()

    def test_finalize_invocation(self):
        # Setup Expected Response
        name = 'name3373707'
        expected_response = {'name': name}
        expected_response = resultstore_upload_pb2.FinalizeInvocationResponse(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        response = client.finalize_invocation()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_upload_pb2.FinalizeInvocationRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_finalize_invocation_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        with pytest.raises(CustomException):
            client.finalize_invocation()

    def test_delete_invocation(self):
        channel = ChannelStub()
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        client.delete_invocation()

        assert len(channel.requests) == 1
        expected_request = resultstore_upload_pb2.DeleteInvocationRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_delete_invocation_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        with pytest.raises(CustomException):
            client.delete_invocation()

    def test_create_target(self):
        # Setup Expected Response
        name = 'name3373707'
        visible = True
        expected_response = {'name': name, 'visible': visible}
        expected_response = target_pb2.Target(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        response = client.create_target()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_upload_pb2.CreateTargetRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_create_target_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        with pytest.raises(CustomException):
            client.create_target()

    def test_update_target(self):
        # Setup Expected Response
        name = 'name3373707'
        visible = True
        expected_response = {'name': name, 'visible': visible}
        expected_response = target_pb2.Target(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        response = client.update_target()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_upload_pb2.UpdateTargetRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_update_target_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        with pytest.raises(CustomException):
            client.update_target()

    def test_merge_target(self):
        # Setup Expected Response
        name = 'name3373707'
        visible = True
        expected_response = {'name': name, 'visible': visible}
        expected_response = target_pb2.Target(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        response = client.merge_target()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_upload_pb2.MergeTargetRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_merge_target_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        with pytest.raises(CustomException):
            client.merge_target()

    def test_finalize_target(self):
        # Setup Expected Response
        name = 'name3373707'
        expected_response = {'name': name}
        expected_response = resultstore_upload_pb2.FinalizeTargetResponse(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        response = client.finalize_target()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_upload_pb2.FinalizeTargetRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_finalize_target_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        with pytest.raises(CustomException):
            client.finalize_target()

    def test_create_configured_target(self):
        # Setup Expected Response
        name = 'name3373707'
        expected_response = {'name': name}
        expected_response = configured_target_pb2.ConfiguredTarget(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        response = client.create_configured_target()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_upload_pb2.CreateConfiguredTargetRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_create_configured_target_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        with pytest.raises(CustomException):
            client.create_configured_target()

    def test_update_configured_target(self):
        # Setup Expected Response
        name = 'name3373707'
        expected_response = {'name': name}
        expected_response = configured_target_pb2.ConfiguredTarget(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        response = client.update_configured_target()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_upload_pb2.UpdateConfiguredTargetRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_update_configured_target_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        with pytest.raises(CustomException):
            client.update_configured_target()

    def test_merge_configured_target(self):
        # Setup Expected Response
        name = 'name3373707'
        expected_response = {'name': name}
        expected_response = configured_target_pb2.ConfiguredTarget(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        response = client.merge_configured_target()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_upload_pb2.MergeConfiguredTargetRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_merge_configured_target_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        with pytest.raises(CustomException):
            client.merge_configured_target()

    def test_finalize_configured_target(self):
        # Setup Expected Response
        name = 'name3373707'
        expected_response = {'name': name}
        expected_response = resultstore_upload_pb2.FinalizeConfiguredTargetResponse(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        response = client.finalize_configured_target()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_upload_pb2.FinalizeConfiguredTargetRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_finalize_configured_target_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        with pytest.raises(CustomException):
            client.finalize_configured_target()

    def test_create_action(self):
        # Setup Expected Response
        name = 'name3373707'
        expected_response = {'name': name}
        expected_response = action_pb2.Action(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        response = client.create_action()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_upload_pb2.CreateActionRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_create_action_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        with pytest.raises(CustomException):
            client.create_action()

    def test_update_action(self):
        # Setup Expected Response
        name = 'name3373707'
        expected_response = {'name': name}
        expected_response = action_pb2.Action(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        response = client.update_action()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_upload_pb2.UpdateActionRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_update_action_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        with pytest.raises(CustomException):
            client.update_action()

    def test_merge_action(self):
        # Setup Expected Response
        name = 'name3373707'
        expected_response = {'name': name}
        expected_response = action_pb2.Action(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        response = client.merge_action()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_upload_pb2.MergeActionRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_merge_action_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        with pytest.raises(CustomException):
            client.merge_action()

    def test_create_configuration(self):
        # Setup Expected Response
        name = 'name3373707'
        display_name = 'displayName1615086568'
        expected_response = {'name': name, 'display_name': display_name}
        expected_response = configuration_pb2.Configuration(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        response = client.create_configuration()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_upload_pb2.CreateConfigurationRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_create_configuration_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        with pytest.raises(CustomException):
            client.create_configuration()

    def test_update_configuration(self):
        # Setup Expected Response
        name = 'name3373707'
        display_name = 'displayName1615086568'
        expected_response = {'name': name, 'display_name': display_name}
        expected_response = configuration_pb2.Configuration(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        response = client.update_configuration()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_upload_pb2.UpdateConfigurationRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_update_configuration_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        with pytest.raises(CustomException):
            client.update_configuration()

    def test_create_file_set(self):
        # Setup Expected Response
        name = 'name3373707'
        expected_response = {'name': name}
        expected_response = file_set_pb2.FileSet(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        response = client.create_file_set()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_upload_pb2.CreateFileSetRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_create_file_set_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        with pytest.raises(CustomException):
            client.create_file_set()

    def test_update_file_set(self):
        # Setup Expected Response
        name = 'name3373707'
        expected_response = {'name': name}
        expected_response = file_set_pb2.FileSet(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        response = client.update_file_set()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_upload_pb2.UpdateFileSetRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_update_file_set_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        with pytest.raises(CustomException):
            client.update_file_set()

    def test_merge_file_set(self):
        # Setup Expected Response
        name = 'name3373707'
        expected_response = {'name': name}
        expected_response = file_set_pb2.FileSet(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        response = client.merge_file_set()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_upload_pb2.MergeFileSetRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_merge_file_set_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        with pytest.raises(CustomException):
            client.merge_file_set()

    def test_upload_batch(self):
        # Setup Expected Response
        expected_response = {}
        expected_response = resultstore_upload_pb2.UploadBatchResponse(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        response = client.upload_batch()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_upload_pb2.UploadBatchRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_upload_batch_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        with pytest.raises(CustomException):
            client.upload_batch()

    def test_get_invocation_upload_metadata(self):
        # Setup Expected Response
        name = 'name3373707'
        resume_token = 'resumeToken1845710695'
        uploader_state = b'-128'
        expected_response = {'name': name, 'resume_token': resume_token, 'uploader_state': uploader_state}
        expected_response = upload_metadata_pb2.UploadMetadata(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        response = client.get_invocation_upload_metadata()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_upload_pb2.GetInvocationUploadMetadataRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_get_invocation_upload_metadata_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreUploadClient()

        with pytest.raises(CustomException):
            client.get_invocation_upload_metadata()
