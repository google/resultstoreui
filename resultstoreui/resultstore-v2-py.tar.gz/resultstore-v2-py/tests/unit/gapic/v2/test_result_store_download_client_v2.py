# -*- coding: utf-8 -*-
#
# Copyright 2020 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Unit tests."""

import mock
import pytest

from google.devtools import resultstore_v2
from google.devtools.resultstore_v2.proto import action_pb2
from google.devtools.resultstore_v2.proto import configuration_pb2
from google.devtools.resultstore_v2.proto import configured_target_pb2
from google.devtools.resultstore_v2.proto import download_metadata_pb2
from google.devtools.resultstore_v2.proto import file_set_pb2
from google.devtools.resultstore_v2.proto import invocation_pb2
from google.devtools.resultstore_v2.proto import resultstore_download_pb2
from google.devtools.resultstore_v2.proto import target_pb2



class MultiCallableStub(object):
    """Stub for the grpc.UnaryUnaryMultiCallable interface."""
    def __init__(self, method, channel_stub):
        self.method = method
        self.channel_stub = channel_stub

    def __call__(self, request, timeout=None, metadata=None, credentials=None):
        self.channel_stub.requests.append((self.method, request))

        response = None
        if self.channel_stub.responses:
            response = self.channel_stub.responses.pop()

        if isinstance(response, Exception):
            raise response

        if response:
            return response


class ChannelStub(object):
    """Stub for the grpc.Channel interface."""
    def __init__(self, responses = []):
        self.responses = responses
        self.requests = []

    def unary_unary(
            self, method, request_serializer=None, response_deserializer=None):
        return MultiCallableStub(method, self)


class CustomException(Exception):
    pass


class TestResultStoreDownloadClient(object):

    def test_get_invocation(self):
        # Setup Expected Response
        name = 'name3373707'
        expected_response = {'name': name}
        expected_response = invocation_pb2.Invocation(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        response = client.get_invocation()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_download_pb2.GetInvocationRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_get_invocation_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        with pytest.raises(CustomException):
            client.get_invocation()

    def test_search_invocations(self):
        # Setup Expected Response
        next_page_token = 'nextPageToken-1530815211'
        expected_response = {'next_page_token': next_page_token}
        expected_response = resultstore_download_pb2.SearchInvocationsResponse(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        response = client.search_invocations()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_download_pb2.SearchInvocationsRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_search_invocations_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        with pytest.raises(CustomException):
            client.search_invocations()

    def test_get_invocation_download_metadata(self):
        # Setup Expected Response
        name = 'name3373707'
        expected_response = {'name': name}
        expected_response = download_metadata_pb2.DownloadMetadata(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        response = client.get_invocation_download_metadata()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_download_pb2.GetInvocationDownloadMetadataRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_get_invocation_download_metadata_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        with pytest.raises(CustomException):
            client.get_invocation_download_metadata()

    def test_get_configuration(self):
        # Setup Expected Response
        name = 'name3373707'
        display_name = 'displayName1615086568'
        expected_response = {'name': name, 'display_name': display_name}
        expected_response = configuration_pb2.Configuration(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        response = client.get_configuration()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_download_pb2.GetConfigurationRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_get_configuration_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        with pytest.raises(CustomException):
            client.get_configuration()

    def test_list_configurations(self):
        # Setup Expected Response
        next_page_token = 'nextPageToken-1530815211'
        expected_response = {'next_page_token': next_page_token}
        expected_response = resultstore_download_pb2.ListConfigurationsResponse(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        response = client.list_configurations()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_download_pb2.ListConfigurationsRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_list_configurations_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        with pytest.raises(CustomException):
            client.list_configurations()

    def test_get_target(self):
        # Setup Expected Response
        name = 'name3373707'
        visible = True
        expected_response = {'name': name, 'visible': visible}
        expected_response = target_pb2.Target(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        response = client.get_target()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_download_pb2.GetTargetRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_get_target_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        with pytest.raises(CustomException):
            client.get_target()

    def test_list_targets(self):
        # Setup Expected Response
        next_page_token = 'nextPageToken-1530815211'
        expected_response = {'next_page_token': next_page_token}
        expected_response = resultstore_download_pb2.ListTargetsResponse(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        response = client.list_targets()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_download_pb2.ListTargetsRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_list_targets_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        with pytest.raises(CustomException):
            client.list_targets()

    def test_get_configured_target(self):
        # Setup Expected Response
        name = 'name3373707'
        expected_response = {'name': name}
        expected_response = configured_target_pb2.ConfiguredTarget(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        response = client.get_configured_target()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_download_pb2.GetConfiguredTargetRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_get_configured_target_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        with pytest.raises(CustomException):
            client.get_configured_target()

    def test_list_configured_targets(self):
        # Setup Expected Response
        next_page_token = 'nextPageToken-1530815211'
        expected_response = {'next_page_token': next_page_token}
        expected_response = resultstore_download_pb2.ListConfiguredTargetsResponse(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        response = client.list_configured_targets()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_download_pb2.ListConfiguredTargetsRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_list_configured_targets_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        with pytest.raises(CustomException):
            client.list_configured_targets()

    def test_get_action(self):
        # Setup Expected Response
        name = 'name3373707'
        expected_response = {'name': name}
        expected_response = action_pb2.Action(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        response = client.get_action()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_download_pb2.GetActionRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_get_action_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        with pytest.raises(CustomException):
            client.get_action()

    def test_list_actions(self):
        # Setup Expected Response
        next_page_token = 'nextPageToken-1530815211'
        expected_response = {'next_page_token': next_page_token}
        expected_response = resultstore_download_pb2.ListActionsResponse(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        response = client.list_actions()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_download_pb2.ListActionsRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_list_actions_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        with pytest.raises(CustomException):
            client.list_actions()

    def test_get_file_set(self):
        # Setup Expected Response
        name = 'name3373707'
        expected_response = {'name': name}
        expected_response = file_set_pb2.FileSet(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        response = client.get_file_set()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_download_pb2.GetFileSetRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_get_file_set_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        with pytest.raises(CustomException):
            client.get_file_set()

    def test_list_file_sets(self):
        # Setup Expected Response
        next_page_token = 'nextPageToken-1530815211'
        expected_response = {'next_page_token': next_page_token}
        expected_response = resultstore_download_pb2.ListFileSetsResponse(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        response = client.list_file_sets()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_download_pb2.ListFileSetsRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_list_file_sets_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        with pytest.raises(CustomException):
            client.list_file_sets()

    def test_traverse_file_sets(self):
        # Setup Expected Response
        next_page_token = 'nextPageToken-1530815211'
        expected_response = {'next_page_token': next_page_token}
        expected_response = resultstore_download_pb2.TraverseFileSetsResponse(**expected_response)

        # Mock the API response
        channel = ChannelStub(responses = [expected_response])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        response = client.traverse_file_sets()
        assert expected_response == response

        assert len(channel.requests) == 1
        expected_request = resultstore_download_pb2.TraverseFileSetsRequest()
        actual_request = channel.requests[0][1]
        assert expected_request == actual_request

    def test_traverse_file_sets_exception(self):
        # Mock the API response
        channel = ChannelStub(responses = [CustomException()])
        patch = mock.patch('google.api_core.grpc_helpers.create_channel')
        with patch as create_channel:
            create_channel.return_value = channel
            client = resultstore_v2.ResultStoreDownloadClient()

        with pytest.raises(CustomException):
            client.traverse_file_sets()
